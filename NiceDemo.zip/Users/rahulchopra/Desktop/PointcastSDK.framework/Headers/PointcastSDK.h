//
//  PointcastSDK.h
//  PointcastSDK
//
//  Created by Rahul Chopra on 12/04/22.
//

#import <Foundation/Foundation.h>

//! Project version number for PointcastSDK.
FOUNDATION_EXPORT double PointcastSDKVersionNumber;

//! Project version string for PointcastSDK.
FOUNDATION_EXPORT const unsigned char PointcastSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PointcastSDK/PublicHeader.h>


